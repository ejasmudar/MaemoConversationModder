###Conversation modder
### Coded by Ejas Mudar
### ejasmudar@gmail.com
### Version 1.1

choice=$(zenity  --list  --text "Chose action" --radiolist  --column "Pick" --column "Action" TRUE "Install Theme" FALSE "Backup Theme" FALSE "Restore Theme" FALSE "Install Portrait Support" FALSE "Change Own Name");
#echo $choice

choice=`echo "$choice"|sed 's/ //g'`
#echo $choice

case $choice in
BackupTheme)

	#sudo /usr/bin/run-standalone.sh conthemer_2.sh backup
	#how to run as root?
	sh conthemer_2.sh backup
	;;


RestoreTheme)
	sh conthemer_2.sh restore
;;

InstallTheme)
	file=`zenity --file-selection --file-filter=*.zip`
	sh conthemer_2.sh $file
;;

InstallPortraitSupport)
	zenity --question --text="This is not guaranteed to work on all themes. Do you want to continue?  (Click outside to cancel)" --ok-label="YES"
		if [ $? -eq 0 ]; then 
			sh convport_2.sh
		fi
	
;;
	
ChangeOwnName)
	sh changename.sh
	;;
	
*)
	zenity --info --text="Error"
;;
	
esac